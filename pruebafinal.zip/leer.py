def leer_archivo(lista, palabra):
    for i in lista:
        lineasplit = i.split()
        for w in lineasplit:
            if (w == palabra):
                return ("existe palabra")

    return "no se encuentra palabra"


def buscar_palabra_en_linea(linea_de_texto, palabra_buscada):
    linea = linea_de_texto.split()
    cantidad = 0
    for w in linea:
        if (w == palabra_buscada):
            cantidad = cantidad + 1
            print(cantidad)

    respuesta = 0
    if (cantidad >= 0):
        respuesta = 1

    return respuesta, cantidad
